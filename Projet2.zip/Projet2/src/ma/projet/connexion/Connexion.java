package ma.projet.connexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.io.FileInputStream;

public class Connexion {
    private static Connection connection;
    private static Properties properties = new Properties();

    static {
        try {
            
            FileInputStream fis = new FileInputStream("base.properties");
            properties.load(fis);

          
            String url = properties.getProperty("jdbc.url");
            String username = properties.getProperty("jdbc.username");
            String password = properties.getProperty("jdbc.password");
            String driver = properties.getProperty("jdbc.driver");

           
            Class.forName(driver);

            
            connection = DriverManager.getConnection(url, username, password);
        } catch (Exception ex) {
            Logger.getLogger(Connexion.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    
    public static Connection getConnection() {
        return connection;
    }

   
    public static Connection getCn() {
        if (connection == null) {
            try {
                String url = properties.getProperty("jdbc.url");
                String username = properties.getProperty("jdbc.username");
                String password = properties.getProperty("jdbc.password");

                connection = DriverManager.getConnection(url, username, password);
            } catch (SQLException ex) {
                Logger.getLogger(Connexion.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return connection;
    }
}
