
package ma.projet.beans;


public class Manager extends Personne {

    public Manager() {
    }

    public Manager(String nom, double slaire) {
        super(nom, slaire);
    }
    
    
}
