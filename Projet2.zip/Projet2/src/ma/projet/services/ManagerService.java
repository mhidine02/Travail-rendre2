
package ma.projet.services;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import ma.projet.beans.Developpeur;
import ma.projet.beans.Manager;
import ma.projet.connexion.Connexion;
import ma.projet.dao.IDao;


public class ManagerService implements IDao<Manager>{

    @Override
    public boolean create(Manager o) {
        boolean r = false;
        String req = "INSERT INTO `manager` (nom, salaire) VALUES (?, ?)";
        try (PreparedStatement ps = Connexion.getCn().prepareStatement(req)) {
            ps.setString(1, o.getNom());
            ps.setDouble(2, o.getSlaire());
            r = ps.executeUpdate() == 1;
        } catch (SQLException ex) {
            Logger.getLogger(ManagerService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return r;
    }

    @Override
    public boolean update(Manager o) {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

    @Override
    public boolean delete(Manager o) {
        boolean r = false;
        try {
            String req = "DELETE FROM `manager` where id  = " + o.getId();
            Statement st = Connexion.getCn().createStatement();
            int n = st.executeUpdate(req);
            if (n == 1) {
                r = true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(ManagerService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return r;
    }

    @Override
    public Manager getById(int id) {
       try {
            String req = "select * from manager where id = " + id;
            Statement st = Connexion.getCn().createStatement();
            ResultSet rs = st.executeQuery(req);
            if (rs.next()) {
                return new Manager(rs.getString("nom"), rs.getDouble("salaire") );
            }
        } catch (SQLException ex) {
            Logger.getLogger(ManagerService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    @Override
    public List<Manager> getAll() {
        List<Manager> manager = new ArrayList<>();
        try {
            String req = "select * from manager";
            Statement st = Connexion.getCn().createStatement();
            ResultSet rs = st.executeQuery(req);
            while (rs.next()) {
                manager.add(new Manager( rs.getString("nom"), rs.getDouble("salaire") ));
            }
        } catch (SQLException ex) {
            Logger.getLogger(DeveloppeurService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return manager;
    }
    
}
