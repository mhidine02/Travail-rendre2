
package ma.projet.beans;


public class Developpeur extends Personne {

    public Developpeur() {
    }

    public Developpeur( String nom, double slaire) {
        super(nom, slaire);
    }
    
    
}
