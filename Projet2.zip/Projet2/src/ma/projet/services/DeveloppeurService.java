
package ma.projet.services;

import java.sql.PreparedStatement;
import ma.projet.beans.Developpeur;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import ma.projet.connexion.Connexion;
import ma.projet.dao.IDao;


public class DeveloppeurService implements IDao<Developpeur>{

    @Override
    public boolean create(Developpeur o) {
        boolean r = false;
        String req = "INSERT INTO `developpeur` (nom, salaire) VALUES (?, ?)";
        try (PreparedStatement ps = Connexion.getCn().prepareStatement(req)) {
            ps.setString(1, o.getNom());
            ps.setDouble(2, o.getSlaire());
            r = ps.executeUpdate() == 1;
        } catch (SQLException ex) {
            Logger.getLogger(DeveloppeurService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return r;

    }

    @Override
    public boolean update(Developpeur o) {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

    @Override
    public boolean delete(Developpeur o) {
        boolean r = false;
        try {
            String req = "DELETE FROM `developpeur` where id  = " + o.getId();
            Statement st = Connexion.getCn().createStatement();
            int n = st.executeUpdate(req);
            if (n == 1) {
                r = true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(DeveloppeurService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return r;
    }

    @Override
    public Developpeur getById(int id) {
        try {
            String req = "select * from developpeur where id = " + id;
            Statement st = Connexion.getCn().createStatement();
            ResultSet rs = st.executeQuery(req);
            if (rs.next()) {
                return new Developpeur( rs.getString("nom"), rs.getDouble("salaire") );
            }
        } catch (SQLException ex) {
            Logger.getLogger(DeveloppeurService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    @Override
    public List<Developpeur> getAll() {
        List<Developpeur> developpeur = new ArrayList<>();
        try {
            String req = "select * from developpeur";
            Statement st = Connexion.getCn().createStatement();
            ResultSet rs = st.executeQuery(req);
            while (rs.next()) {
                developpeur.add(new Developpeur(rs.getString("nom"), rs.getDouble("salaire") ));
            }
        } catch (SQLException ex) {
            Logger.getLogger(DeveloppeurService.class.getName()).log(Level.SEVERE, null, ex);
        }
        return developpeur;
    }
    
    
}
