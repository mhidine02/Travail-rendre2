
package ma.projet.test;

import java.util.Date;
import java.util.List;
import ma.projet.beans.Developpeur;
import ma.projet.beans.Manager;
import ma.projet.services.DeveloppeurService;
import ma.projet.services.ManagerService;


public class Entreprise {
     public static void main(String[] args) {
         DeveloppeurService de  = new DeveloppeurService();
        ManagerService me  = new ManagerService();
        
        //de.create(new Developpeur("sadaq",1000 ));
        //de.create(new Developpeur("salmi",2000 ));
        //me.create(new Manager("mohidine",8000 ));
        //de.create(new Developpeur("khazrej",4000 ));
        //me.create(new Manager("directeur",10000 ));
        
        List<Manager> managers = me.getAll();
        managers.sort((man1, man2) -> Double.compare(man2.getSlaire(), man1.getSlaire()));
        for (Manager man : managers) {
            System.out.println("Nom: " + man.getNom() + ", Salaire: " + man.getSlaire());
        }
        List<Developpeur> developpeurs = de.getAll();
        developpeurs.sort((dev1, dev2) -> Double.compare(dev2.getSlaire(), dev1.getSlaire()));
        for (Developpeur dev : developpeurs) {
            System.out.println("Nom: " + dev.getNom() + ", Salaire: " + dev.getSlaire());
        }
        
        
        
        
    }
    
}
